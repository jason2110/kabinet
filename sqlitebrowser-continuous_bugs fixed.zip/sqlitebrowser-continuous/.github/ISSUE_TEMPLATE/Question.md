---
name: Question
about: Ask a question related to this project or SQLite in general
title: ''
labels: ''
assignees: ''

---

<!--
Thanks for coming here to ask a question. :)

Before asking your question, please make sure you have searched for an existing similar question in the project Issues and Wiki.
-->

What is your question
-----------------------
